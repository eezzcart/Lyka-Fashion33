import { create } from 'zustand';

export type Product = {
  id: string;
  name: string;
  price: number;
  image_url: string;
  category: string;
  description: string;
  purity: string;
  featured: boolean;
  created_at: string;
};

export type SiteConfig = {
  hero_title: string;
  hero_tagline: string;
  hero_subtitle: string;
  contact_phone: string;
  whatsapp_number: string;
  offer_bar_enabled: boolean;
  offer_bar_text: string;
  founder_name: string;
};

const defaultConfig: SiteConfig = {
  hero_title: 'ROYAL SILVER',
  hero_tagline: 'Handcrafted with purpose. Worn with pride.',
  hero_subtitle: 'By Founder Faisel Nazar',
  contact_phone: '7006630873',
  whatsapp_number: '7006630873',
  offer_bar_enabled: true,
  offer_bar_text: '✦ Free Luxury Packaging on all orders above ₹2,499 ✦ Pan-India Shipping Available ✦ COD Available',
  founder_name: 'Faisel Nazar',
};

const defaultProducts: Product[] = [
  {
    id: '1',
    name: 'Imperial Band Ring',
    price: 1899,
    image_url: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&q=80',
    category: 'Bands',
    description: 'A timeless sterling silver band with a mirror-polished finish. Perfect for everyday elegance.',
    purity: '92.5',
    featured: true,
    created_at: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Crescent Moon Ring',
    price: 2299,
    image_url: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&q=80',
    category: 'Statement Rings',
    description: 'Inspired by celestial beauty, this crescent design is hand-carved by master artisans.',
    purity: '92.5',
    featured: true,
    created_at: new Date().toISOString(),
  },
  {
    id: '3',
    name: 'Eternity Braided Band',
    price: 2799,
    image_url: 'https://images.unsplash.com/photo-1602173574767-37ac01994b2a?w=600&q=80',
    category: 'Bands',
    description: 'Three strands of pure silver woven into infinity — a symbol of eternal bonds.',
    purity: '92.5',
    featured: false,
    created_at: new Date().toISOString(),
  },
  {
    id: '4',
    name: 'Solitaire Signet Ring',
    price: 3499,
    image_url: 'https://images.unsplash.com/photo-1611955167811-4711904bb9f8?w=600&q=80',
    category: 'Statement Rings',
    description: 'A bold signet ring with an antiqued finish, combining heritage and modern luxury.',
    purity: '92.5',
    featured: true,
    created_at: new Date().toISOString(),
  },
  {
    id: '5',
    name: 'Minimalist Stack Ring',
    price: 999,
    image_url: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&q=80',
    category: 'Stackable',
    description: 'Thin, stackable silver ring — designed for the modern minimalist.',
    purity: '92.5',
    featured: false,
    created_at: new Date().toISOString(),
  },
  {
    id: '6',
    name: 'Royal Engraved Band',
    price: 3199,
    image_url: 'https://images.unsplash.com/photo-1573408301185-9519f94816c8?w=600&q=80',
    category: 'Custom',
    description: 'Personalized engraving on a wide sterling silver band. Custom orders welcome.',
    purity: '92.5',
    featured: true,
    created_at: new Date().toISOString(),
  },
];

type DataStore = {
  products: Product[];
  config: SiteConfig;
  previewConfig: SiteConfig | null;
  isPreviewMode: boolean;
  adminAuthenticated: boolean;
  // Actions
  setProducts: (products: Product[]) => void;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  setConfig: (config: SiteConfig) => void;
  setPreviewConfig: (config: SiteConfig | null) => void;
  setPreviewMode: (enabled: boolean) => void;
  setAdminAuthenticated: (auth: boolean) => void;
  getActiveConfig: () => SiteConfig;
};

export const useDataStore = create<DataStore>((set, get) => ({
  products: defaultProducts,
  config: defaultConfig,
  previewConfig: null,
  isPreviewMode: false,
  adminAuthenticated: false,

  setProducts: (products) => set({ products }),
  
  addProduct: (product) => set((state) => ({
    products: [product, ...state.products],
  })),

  updateProduct: (id, updatedProduct) => set((state) => ({
    products: state.products.map((p) =>
      p.id === id ? { ...p, ...updatedProduct } : p
    ),
  })),

  deleteProduct: (id) => set((state) => ({
    products: state.products.filter((p) => p.id !== id),
  })),

  setConfig: (config) => set({ config, previewConfig: null, isPreviewMode: false }),
  
  setPreviewConfig: (config) => set({ previewConfig: config }),
  
  setPreviewMode: (enabled) => set({ isPreviewMode: enabled }),
  
  setAdminAuthenticated: (auth) => set({ adminAuthenticated: auth }),

  getActiveConfig: () => {
    const state = get();
    return state.isPreviewMode && state.previewConfig ? state.previewConfig : state.config;
  },
}));
