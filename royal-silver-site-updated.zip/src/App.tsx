import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';

// Landing Page Components
import AnnouncementBar from './components/AnnouncementBar';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import CollectionsSection from './components/CollectionsSection';
import CraftSection from './components/CraftSection';
import StatsSection from './components/StatsSection';
import ContactSection from './components/ContactSection';
import MobileBottomNav from './components/MobileBottomNav';
import Footer from './components/Footer';

// Admin
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import AboutPage from './pages/AboutPage';

// Store
import { useDataStore } from './store/dataStore';

function LandingPage() {
  return (
    <div className="bg-black min-h-screen">
      {/* Noise texture */}
      <div className="noise-overlay" />
      
      <AnnouncementBar />
      <Navbar />
      <main>
        <HeroSection />
        <CollectionsSection />
        <CraftSection />
        <StatsSection />
        <ContactSection />
      </main>
      <Footer />
      <MobileBottomNav />
      
      {/* Bottom padding for mobile nav */}
      <div className="h-20 md:h-0" />
    </div>
  );
}

function AdminPage() {
  const adminAuthenticated = useDataStore((s) => s.adminAuthenticated);
  const setAdminAuthenticated = useDataStore((s) => s.setAdminAuthenticated);
  const [authed, setAuthed] = useState(adminAuthenticated);

  useEffect(() => {
    setAuthed(adminAuthenticated);
  }, [adminAuthenticated]);

  const handleLogout = () => {
    setAdminAuthenticated(false);
    setAuthed(false);
  };

  if (!authed) {
    return <AdminLogin onLogin={() => setAuthed(true)} />;
  }

  return <AdminDashboard onLogout={handleLogout} />;
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="*" element={<LandingPage />} />
      </Routes>
    </BrowserRouter>
  );
}
