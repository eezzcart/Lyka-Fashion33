import { motion } from 'framer-motion';
import { MessageCircle, Star, Tag } from 'lucide-react';
import { useDataStore } from '../store/dataStore';

const categoryColors: Record<string, string> = {
  'Bands': 'rgba(192,192,192,0.15)',
  'Statement Rings': 'rgba(212,175,55,0.15)',
  'Stackable': 'rgba(150,200,255,0.15)',
  'Custom': 'rgba(200,150,255,0.15)',
};

const containerVariants = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: 'easeOut' as const },
  },
};

export default function CollectionsSection() {
  const products = useDataStore((s) => s.products);
  const getActiveConfig = useDataStore((s) => s.getActiveConfig);
  const config = getActiveConfig();

  return (
    <section id="collections" className="py-24 md:py-32 px-6 relative">
      {/* Section background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-zinc-950/50 to-black pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 md:mb-20"
        >
          <p className="text-xs tracking-[0.4em] uppercase text-gray-500 font-sans mb-4">
            ✦ Curated for You ✦
          </p>
          <h2
            className="font-serif text-silver-gradient mb-4"
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(2.5rem, 6vw, 5rem)',
              fontWeight: 400,
              lineHeight: 1.1,
            }}
          >
            Our Collections
          </h2>
          <div className="section-divider mt-6" />
          <p className="mt-6 text-gray-400 font-sans text-sm max-w-lg mx-auto tracking-wide">
            Each piece is individually crafted from 92.5 sterling silver — a mark of purity and excellence.
          </p>
        </motion.div>

        {/* Product Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-50px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10"
        >
          {products.map((product) => (
            <motion.div
              key={product.id}
              variants={cardVariants}
              className="product-card group relative overflow-hidden rounded-sm"
              style={{
                background: 'rgba(255,255,255,0.02)',
                border: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              {/* Image */}
              <div className="relative overflow-hidden aspect-square">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&q=80';
                  }}
                />
                {/* Image overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                {/* Featured badge */}
                {product.featured && (
                  <div className="absolute top-3 left-3 flex items-center gap-1 glass px-2 py-1 rounded-full">
                    <Star size={10} fill="currentColor" style={{ color: '#c9a84c' }} />
                    <span className="text-xs text-yellow-400/80 font-sans tracking-wider">Featured</span>
                  </div>
                )}

                {/* Purity badge */}
                <div className="absolute top-3 right-3 glass px-2.5 py-1 rounded-full">
                  <span className="text-xs font-semibold tracking-wider font-sans" style={{ color: '#c0c0c0' }}>
                    {product.purity}% Pure
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Category */}
                <div className="flex items-center gap-1.5 mb-2">
                  <Tag size={10} className="text-gray-500" />
                  <span
                    className="text-xs tracking-widest uppercase font-sans"
                    style={{
                      color: '#888',
                      backgroundColor: categoryColors[product.category] || 'rgba(192,192,192,0.1)',
                      padding: '2px 8px',
                      borderRadius: '2px',
                    }}
                  >
                    {product.category}
                  </span>
                </div>

                {/* Name */}
                <h3
                  className="font-serif mb-1 text-gray-100 group-hover:text-white transition-colors"
                  style={{
                    fontFamily: 'Cormorant Garamond, serif',
                    fontSize: '1.35rem',
                    fontWeight: 500,
                  }}
                >
                  {product.name}
                </h3>

                {/* Description */}
                <p className="text-xs text-gray-500 font-sans mb-4 leading-relaxed line-clamp-2">
                  {product.description}
                </p>

                {/* Price & CTA */}
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500 font-sans tracking-wider mb-0.5">Starting from</p>
                    <p
                      className="font-serif text-2xl font-medium"
                      style={{
                        fontFamily: 'Cormorant Garamond, serif',
                        background: 'linear-gradient(135deg, #c0c0c0, #f0f0f0)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        backgroundClip: 'text',
                      }}
                    >
                      ₹{product.price.toLocaleString('en-IN')}
                    </p>
                  </div>

                  <a
                    href={`https://wa.me/91${config.whatsapp_number}?text=Hi! I'm interested in the *${product.name}* (₹${product.price.toLocaleString('en-IN')}). Can you share more details?`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="whatsapp-btn flex items-center gap-2 px-4 py-2.5 rounded-sm text-white text-xs font-semibold tracking-wider font-sans"
                  >
                    <MessageCircle size={14} />
                    Buy Now
                  </a>
                </div>
              </div>

              {/* Hover border glow */}
              <div
                className="absolute inset-0 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{ boxShadow: 'inset 0 0 0 1px rgba(192,192,192,0.15)' }}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-16"
        >
          <p className="text-gray-500 font-sans text-sm mb-6 tracking-wide">
            Can't find what you're looking for? We craft custom orders too.
          </p>
          <a
            href={`https://wa.me/91${config.whatsapp_number}?text=Hi! I'd like to discuss a custom silver jewelry order.`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3 border border-white/15 text-sm tracking-widest uppercase text-gray-300 hover:text-white hover:border-white/40 transition-all duration-300 font-sans"
            style={{ borderRadius: '2px' }}
          >
            <MessageCircle size={14} />
            Request Custom Order
          </a>
        </motion.div>
      </div>
    </section>
  );
}
