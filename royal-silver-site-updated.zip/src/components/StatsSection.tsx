import { motion } from 'framer-motion';
import { Shield, Users, Truck, Award } from 'lucide-react';

const stats = [
  {
    value: '92.5%',
    label: 'Silver Purity',
    sublabel: 'Certified Sterling',
    icon: Shield,
    description: 'Every piece carries the hallmark of 92.5 pure sterling silver, the international standard of excellence.',
  },
  {
    value: '3K+',
    label: 'Happy Clients',
    sublabel: 'Across India',
    icon: Users,
    description: 'Over 3,000 customers trust Royal Silver for their personal milestones and everyday elegance.',
  },
  {
    value: '∞',
    label: 'Custom Designs',
    sublabel: 'Yours Exclusively',
    icon: Award,
    description: 'We craft bespoke pieces that are uniquely yours — no two custom orders are ever the same.',
  },
  {
    value: 'Pan-India',
    label: 'Shipping',
    sublabel: 'Fast & Insured',
    icon: Truck,
    description: 'Secure, insured shipping to every corner of India. Cash on delivery available for most cities.',
  },
];

export default function StatsSection() {
  return (
    <section id="stats" className="py-24 md:py-32 px-6 relative overflow-hidden">
      {/* Background accent */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 80% 60% at 50% 50%, rgba(192,192,192,0.03) 0%, transparent 70%)',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 md:mb-24"
        >
          <p className="text-xs tracking-[0.4em] uppercase text-gray-500 font-sans mb-4">
            ✦ Why Choose Us ✦
          </p>
          <h2
            className="font-serif mb-4"
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(2.5rem, 6vw, 5rem)',
              fontWeight: 400,
              lineHeight: 1.1,
              background: 'linear-gradient(135deg, #c0c0c0 0%, #f5f5f5 40%, #a8a8a8 60%, #e8e8e8 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Crafted to Last a Lifetime
          </h2>
          <div className="section-divider mt-6" />
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="group relative p-8 rounded-sm text-center"
                style={{
                  background: 'rgba(255,255,255,0.02)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  transition: 'all 0.4s ease',
                }}
              >
                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-6"
                  style={{
                    background: 'rgba(192,192,192,0.06)',
                    border: '1px solid rgba(192,192,192,0.1)',
                  }}
                >
                  <Icon size={18} style={{ color: '#c0c0c0' }} />
                </div>

                {/* Value */}
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 + 0.2 }}
                >
                  <p
                    className="font-serif mb-1 leading-none"
                    style={{
                      fontFamily: 'Cormorant Garamond, serif',
                      fontSize: stat.value.length > 5 ? '2.5rem' : '3.5rem',
                      fontWeight: 600,
                      background: 'linear-gradient(135deg, #c0c0c0, #ffffff)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      backgroundClip: 'text',
                    }}
                  >
                    {stat.value}
                  </p>
                  <p
                    className="font-serif text-gray-300 mb-0.5"
                    style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.1rem' }}
                  >
                    {stat.label}
                  </p>
                  <p className="text-xs text-gray-600 tracking-widest uppercase font-sans mb-4">
                    {stat.sublabel}
                  </p>
                </motion.div>

                {/* Description */}
                <p className="text-gray-500 font-sans text-xs leading-relaxed">
                  {stat.description}
                </p>

                {/* Hover glow */}
                <div
                  className="absolute inset-0 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{ boxShadow: 'inset 0 0 0 1px rgba(192,192,192,0.12), 0 0 40px rgba(192,192,192,0.03)' }}
                />
              </motion.div>
            );
          })}
        </div>

        {/* Full-width quote */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-20 text-center"
        >
          <div
            className="inline-block p-10 rounded-sm max-w-3xl mx-auto relative"
            style={{
              background: 'rgba(255,255,255,0.015)',
              border: '1px solid rgba(255,255,255,0.05)',
            }}
          >
            <span
              className="absolute -top-5 left-1/2 -translate-x-1/2 text-6xl font-serif opacity-20"
              style={{ fontFamily: 'Cormorant Garamond, serif', color: '#c0c0c0', lineHeight: 1 }}
            >
              "
            </span>
            <p
              className="font-serif text-gray-300 leading-relaxed"
              style={{
                fontFamily: 'Cormorant Garamond, serif',
                fontSize: 'clamp(1.1rem, 2.5vw, 1.6rem)',
                fontStyle: 'italic',
                fontWeight: 300,
              }}
            >
              Silver is not just a metal. It is a mirror to the soul — pure, timeless, and endlessly beautiful.
            </p>
            <div className="section-divider mt-6 mb-4" />
            <p className="text-xs tracking-[0.3em] uppercase text-gray-600 font-sans">
              — Faisel Nazar, Founder
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
