import { motion } from 'framer-motion';
import { Home, Grid, Hammer, HelpCircle, MessageCircle } from 'lucide-react';
import { useState } from 'react';
import { useDataStore } from '../store/dataStore';

const navItems = [
  { icon: Home, label: 'Home', href: '#hero' },
  { icon: Grid, label: 'Shop', href: '#collections' },
  { icon: Hammer, label: 'Craft', href: '#craft' },
  { icon: HelpCircle, label: 'FAQ', href: '#contact' },
];

export default function MobileBottomNav() {
  const [active, setActive] = useState('Home');
  const getActiveConfig = useDataStore((s) => s.getActiveConfig);
  const config = getActiveConfig();

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, delay: 1.5 }}
      className="mobile-bottom-nav fixed bottom-0 left-0 right-0 z-50 md:hidden"
    >
      <div className="flex items-center justify-around px-2 py-2 safe-area-bottom">
        {navItems.map(({ icon: Icon, label, href }) => (
          <a
            key={label}
            href={href}
            onClick={() => setActive(label)}
            className="flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all duration-200 min-w-[60px]"
            style={{
              color: active === label ? '#c0c0c0' : '#555',
              background: active === label ? 'rgba(192,192,192,0.08)' : 'transparent',
            }}
          >
            <Icon size={18} />
            <span className="text-xs font-sans tracking-wide">{label}</span>
          </a>
        ))}

        {/* WhatsApp CTA */}
        <a
          href={`https://wa.me/91${config.whatsapp_number}?text=Hi! I'm interested in Royal Silver jewelry.`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center gap-1 py-2 px-3 rounded-lg min-w-[60px]"
          style={{ color: '#25D366' }}
        >
          <MessageCircle size={18} />
          <span className="text-xs font-sans tracking-wide">Buy</span>
        </a>
      </div>
    </motion.div>
  );
}
