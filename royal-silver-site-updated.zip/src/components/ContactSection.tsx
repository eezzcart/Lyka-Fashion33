import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus, MessageCircle, Phone, Mail, MapPin } from 'lucide-react';
import { useDataStore } from '../store/dataStore';

const faqs = [
  {
    category: 'Care Instructions',
    items: [
      {
        q: 'How do I clean my silver jewelry?',
        a: 'Use a soft silver polishing cloth or a mild soap solution with warm water. Gently rub in circular motions, rinse thoroughly, and pat dry with a lint-free cloth. Avoid harsh chemicals or abrasive materials.',
      },
      {
        q: 'How do I prevent tarnishing?',
        a: 'Store your silver jewelry in an airtight zip-lock bag or our provided velvet pouch when not in use. Keep it away from perfumes, lotions, and chlorinated water. Regular wearing actually helps prevent tarnish.',
      },
      {
        q: 'Can I wear my silver ring in the shower?',
        a: 'We recommend removing your ring before showering or swimming. While sterling silver is durable, prolonged exposure to water and chemicals can accelerate tarnishing. Pat dry immediately if it gets wet.',
      },
      {
        q: 'What is 92.5 sterling silver?',
        a: '92.5 sterling silver (also known as 925 silver) is an alloy containing 92.5% pure silver and 7.5% other metals (usually copper) for added strength. It is the international hallmark standard for high-quality silver jewelry.',
      },
    ],
  },
  {
    category: 'Shipping & Orders',
    items: [
      {
        q: 'Do you ship across all of India?',
        a: 'Yes! We offer Pan-India shipping through trusted courier partners. Most metropolitan cities receive delivery within 3-5 business days. Tier-2 and Tier-3 cities may take 5-7 business days.',
      },
      {
        q: 'Is Cash on Delivery (COD) available?',
        a: 'COD is available for most pin codes across India. A nominal COD charge may apply. For custom orders, we require a 50% advance payment before production begins.',
      },
      {
        q: 'How do I track my order?',
        a: 'Once your order is dispatched, you will receive a WhatsApp message with the tracking number and courier partner details. You can track your shipment in real-time on the courier\'s website.',
      },
      {
        q: 'What is your return/exchange policy?',
        a: 'We accept returns within 7 days of delivery for manufacturing defects. Since all pieces are handcrafted, minor variations are expected and celebrated. Custom orders are non-refundable once production begins.',
      },
      {
        q: 'How do I place a custom order?',
        a: 'Simply WhatsApp us on our contact number with your design inspiration, size requirements, and budget. Our design team will get back to you within 24 hours with a quote and timeline.',
      },
    ],
  },
];

function AccordionItem({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false);

  return (
    <div
      className="border-b"
      style={{ borderColor: 'rgba(255,255,255,0.06)' }}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full text-left py-5 flex items-start justify-between gap-4 group"
      >
        <span
          className="font-sans text-sm text-gray-300 group-hover:text-white transition-colors leading-relaxed"
          style={{ letterSpacing: '0.01em' }}
        >
          {question}
        </span>
        <span
          className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center mt-0.5 transition-all duration-300"
          style={{
            background: open ? 'rgba(192,192,192,0.15)' : 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
          }}
        >
          {open ? (
            <Minus size={12} style={{ color: '#c0c0c0' }} />
          ) : (
            <Plus size={12} className="text-gray-500" />
          )}
        </span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <p className="font-sans text-sm text-gray-500 leading-relaxed pb-5">
              {answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function ContactSection() {
  const getActiveConfig = useDataStore((s) => s.getActiveConfig);
  const config = getActiveConfig();

  return (
    <section id="contact" className="py-24 md:py-32 px-6 relative">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(192,192,192,0.02) 0%, transparent 70%)',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-xs tracking-[0.4em] uppercase text-gray-500 font-sans mb-4">
            ✦ We're Here to Help ✦
          </p>
          <h2
            className="font-serif mb-4"
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(2.5rem, 6vw, 5rem)',
              fontWeight: 400,
              lineHeight: 1.1,
              background: 'linear-gradient(135deg, #c0c0c0 0%, #f5f5f5 40%, #a8a8a8 60%, #e8e8e8 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Contact & FAQ
          </h2>
          <div className="section-divider mt-6" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Contact Card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div
              className="p-8 rounded-sm mb-8"
              style={{
                background: 'rgba(255,255,255,0.02)',
                border: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              <h3
                className="font-serif text-gray-200 mb-6"
                style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.75rem' }}
              >
                Get in Touch
              </h3>

              {/* Contact methods */}
              <div className="space-y-5">
                <a
                  href={`https://wa.me/91${config.whatsapp_number}?text=Hi Royal Silver! I'd like to inquire about your jewelry.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 rounded-sm transition-all duration-300 group"
                  style={{
                    background: 'rgba(37,211,102,0.05)',
                    border: '1px solid rgba(37,211,102,0.1)',
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(37,211,102,0.15)' }}
                  >
                    <MessageCircle size={16} style={{ color: '#25D366' }} />
                  </div>
                  <div>
                    <p className="text-xs tracking-widest uppercase text-gray-500 font-sans mb-0.5">WhatsApp</p>
                    <p className="text-gray-200 font-sans text-sm group-hover:text-white transition-colors">
                      +91 {config.whatsapp_number}
                    </p>
                  </div>
                </a>

                <a
                  href={`tel:+91${config.contact_phone}`}
                  className="flex items-center gap-4 p-4 rounded-sm transition-all duration-300 group"
                  style={{
                    background: 'rgba(255,255,255,0.02)',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{
                      background: 'rgba(192,192,192,0.08)',
                      border: '1px solid rgba(192,192,192,0.12)',
                    }}
                  >
                    <Phone size={16} style={{ color: '#c0c0c0' }} />
                  </div>
                  <div>
                    <p className="text-xs tracking-widest uppercase text-gray-500 font-sans mb-0.5">Phone</p>
                    <p className="text-gray-200 font-sans text-sm group-hover:text-white transition-colors">
                      +91 {config.contact_phone}
                    </p>
                  </div>
                </a>

                <div
                  className="flex items-center gap-4 p-4 rounded-sm"
                  style={{
                    background: 'rgba(255,255,255,0.02)',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{
                      background: 'rgba(192,192,192,0.08)',
                      border: '1px solid rgba(192,192,192,0.12)',
                    }}
                  >
                    <Mail size={16} style={{ color: '#c0c0c0' }} />
                  </div>
                  <div>
                    <p className="text-xs tracking-widest uppercase text-gray-500 font-sans mb-0.5">Email</p>
                    <p className="text-gray-200 font-sans text-sm">royalsilver.in@gmail.com</p>
                  </div>
                </div>

                <div
                  className="flex items-center gap-4 p-4 rounded-sm"
                  style={{
                    background: 'rgba(255,255,255,0.02)',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{
                      background: 'rgba(192,192,192,0.08)',
                      border: '1px solid rgba(192,192,192,0.12)',
                    }}
                  >
                    <MapPin size={16} style={{ color: '#c0c0c0' }} />
                  </div>
                  <div>
                    <p className="text-xs tracking-widest uppercase text-gray-500 font-sans mb-0.5">Location</p>
                    <p className="text-gray-200 font-sans text-sm">Pan-India Shipping Available</p>
                  </div>
                </div>
              </div>

              {/* WhatsApp CTA */}
              <div className="mt-8">
                <a
                  href={`https://wa.me/91${config.whatsapp_number}?text=Hi! I'd like to place an order for silver jewelry.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="whatsapp-btn w-full flex items-center justify-center gap-3 py-4 rounded-sm text-white font-semibold text-sm tracking-widest uppercase font-sans"
                >
                  <MessageCircle size={18} />
                  Chat with Us on WhatsApp
                </a>
              </div>
            </div>

            {/* Founder note */}
            <div
              className="p-6 rounded-sm"
              style={{
                background: 'rgba(255,255,255,0.015)',
                border: '1px solid rgba(255,255,255,0.05)',
              }}
            >
              <p
                className="font-serif text-gray-400 leading-relaxed text-lg italic"
                style={{ fontFamily: 'Cormorant Garamond, serif' }}
              >
                "Every query, every idea, every dream — I read them personally.
                Your vision is our mission."
              </p>
              <div className="flex items-center gap-3 mt-4">
                <div className="section-divider" style={{ width: '30px', margin: 0 }} />
                <p className="text-xs tracking-widest uppercase text-gray-600 font-sans">
                  {config.founder_name}, Founder
                </p>
              </div>
            </div>
          </motion.div>

          {/* FAQ Accordions */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="space-y-10"
          >
            {faqs.map((section) => (
              <div key={section.category}>
                <h3
                  className="font-sans text-xs tracking-[0.35em] uppercase mb-4 pb-3"
                  style={{
                    color: '#c0c0c0',
                    borderBottom: '1px solid rgba(192,192,192,0.1)',
                    letterSpacing: '0.3em',
                  }}
                >
                  {section.category}
                </h3>
                <div>
                  {section.items.map((item) => (
                    <AccordionItem key={item.q} question={item.q} answer={item.a} />
                  ))}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
