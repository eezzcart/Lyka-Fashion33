import { createClient } from '@supabase/supabase-js';

// Supabase configuration - using demo/mock mode when no real credentials provided
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://demo.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'demo-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Product = {
  id: string;
  name: string;
  price: number;
  image_url: string;
  category: string;
  description: string;
  purity: string;
  featured: boolean;
  created_at: string;
};

export type SiteConfig = {
  id: string;
  hero_title: string;
  hero_tagline: string;
  hero_subtitle: string;
  contact_phone: string;
  whatsapp_number: string;
  offer_bar_enabled: boolean;
  offer_bar_text: string;
  founder_name: string;
  updated_at: string;
};
