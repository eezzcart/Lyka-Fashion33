import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Crown, LayoutDashboard, Package, Settings, LogOut,
  Plus, Edit, Trash2, ExternalLink, Eye, EyeOff,
  Save, X, ToggleLeft, ToggleRight, MessageSquare, Phone
} from 'lucide-react';
import { useDataStore, type Product, type SiteConfig } from '../store/dataStore';

type TabType = 'products' | 'content' | 'marketing';

function ProductForm({
  product,
  onSave,
  onCancel,
}: {
  product: Partial<Product>;
  onSave: (p: Partial<Product>) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<Partial<Product>>({
    name: '',
    price: 0,
    image_url: '',
    category: 'Bands',
    description: '',
    purity: '92.5',
    featured: false,
    ...product,
  });

  const categories = ['Bands', 'Statement Rings', 'Stackable', 'Custom'];

  const update = (key: keyof Product, value: string | number | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)' }}
    >
      <div
        className="w-full max-w-lg rounded-sm overflow-hidden"
        style={{ background: '#0a0a0a', border: '1px solid rgba(255,255,255,0.08)' }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-6 py-4"
          style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}
        >
          <h3 className="font-serif text-gray-200 text-xl" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
            {product.id ? 'Edit Product' : 'Add New Product'}
          </h3>
          <button onClick={onCancel} className="text-gray-500 hover:text-gray-300 transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Product Name</label>
              <input
                className="luxury-input"
                value={form.name}
                onChange={(e) => update('name', e.target.value)}
                placeholder="e.g. Imperial Band Ring"
              />
            </div>
            <div>
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Price (₹)</label>
              <input
                className="luxury-input"
                type="number"
                value={form.price}
                onChange={(e) => update('price', Number(e.target.value))}
                placeholder="1899"
              />
            </div>
            <div>
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Category</label>
              <select
                className="luxury-input"
                value={form.category}
                onChange={(e) => update('category', e.target.value)}
                style={{ cursor: 'pointer' }}
              >
                {categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Image URL</label>
              <input
                className="luxury-input"
                value={form.image_url}
                onChange={(e) => update('image_url', e.target.value)}
                placeholder="https://..."
              />
              {form.image_url && (
                <div className="mt-2 h-28 rounded-sm overflow-hidden">
                  <img src={form.image_url} alt="preview" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
            <div className="col-span-2">
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Description</label>
              <textarea
                className="luxury-input resize-none"
                rows={3}
                value={form.description}
                onChange={(e) => update('description', e.target.value)}
                placeholder="Describe this piece..."
              />
            </div>
            <div>
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Purity</label>
              <input
                className="luxury-input"
                value={form.purity}
                onChange={(e) => update('purity', e.target.value)}
                placeholder="92.5"
              />
            </div>
            <div>
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Featured</label>
              <button
                type="button"
                onClick={() => update('featured', !form.featured)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-sm transition-all duration-200 font-sans text-xs tracking-wider"
                style={{
                  background: form.featured ? 'rgba(192,192,192,0.12)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${form.featured ? 'rgba(192,192,192,0.3)' : 'rgba(255,255,255,0.08)'}`,
                  color: form.featured ? '#c0c0c0' : '#666',
                }}
              >
                {form.featured ? <ToggleRight size={16} /> : <ToggleLeft size={16} />}
                {form.featured ? 'Featured' : 'Not Featured'}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div
          className="px-6 py-4 flex gap-3"
          style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}
        >
          <button
            onClick={() => onSave(form)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-semibold tracking-wider font-sans text-black transition-all duration-200"
            style={{
              background: 'linear-gradient(135deg, #d0d0d0 0%, #f5f5f5 100%)',
              borderRadius: '2px',
            }}
          >
            <Save size={14} />
            {product.id ? 'Save Changes' : 'Add Product'}
          </button>
          <button
            onClick={onCancel}
            className="px-5 py-2.5 text-sm font-sans text-gray-400 hover:text-gray-200 transition-colors"
            style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '2px',
            }}
          >
            Cancel
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  const [activeTab, setActiveTab] = useState<TabType>('products');
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const { products, config, addProduct, updateProduct, deleteProduct, setConfig, setPreviewConfig, setPreviewMode } = useDataStore();
  const [draftConfig, setDraftConfig] = useState<SiteConfig>({ ...config });
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveProduct = (form: Partial<Product>) => {
    if (form.id) {
      updateProduct(form.id, form);
    } else {
      addProduct({
        ...form,
        id: Date.now().toString(),
        created_at: new Date().toISOString(),
        name: form.name || '',
        price: form.price || 0,
        image_url: form.image_url || '',
        category: form.category || 'Bands',
        description: form.description || '',
        purity: form.purity || '92.5',
        featured: form.featured || false,
      } as Product);
    }
    setEditingProduct(null);
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Delete this product? This cannot be undone.')) {
      deleteProduct(id);
    }
  };

  const handleConfigChange = (key: keyof SiteConfig, value: string | boolean) => {
    const updated = { ...draftConfig, [key]: value };
    setDraftConfig(updated);
    if (isPreviewMode) {
      setPreviewConfig(updated);
    }
  };

  const togglePreview = () => {
    const next = !isPreviewMode;
    setIsPreviewMode(next);
    setPreviewMode(next);
    if (next) {
      setPreviewConfig(draftConfig);
    } else {
      setPreviewConfig(null);
    }
  };

  const handleSaveConfig = () => {
    setConfig(draftConfig);
    setPreviewMode(false);
    setIsPreviewMode(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const tabs: { key: TabType; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
    { key: 'products', label: 'Products', icon: Package },
    { key: 'content', label: 'Content', icon: Settings },
    { key: 'marketing', label: 'Marketing', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-black flex text-gray-200" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ duration: 0.3 }}
            className="admin-sidebar w-64 flex flex-col fixed inset-y-0 left-0 z-20"
          >
            {/* Logo */}
            <div className="px-6 py-6 flex items-center gap-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(192,192,192,0.08)', border: '1px solid rgba(192,192,192,0.15)' }}
              >
                <Crown size={14} style={{ color: '#c0c0c0' }} />
              </div>
              <div>
                <p className="text-xs font-semibold tracking-widest uppercase" style={{ fontFamily: 'Cormorant Garamond, serif', color: '#e0e0e0' }}>
                  Royal Silver
                </p>
                <p className="text-xs text-gray-600 font-sans">CMS Dashboard</p>
              </div>
            </div>

            {/* Overview stat */}
            <div className="px-6 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-sm text-center" style={{ background: 'rgba(255,255,255,0.03)' }}>
                  <p className="font-serif text-xl" style={{ fontFamily: 'Cormorant Garamond, serif', color: '#c0c0c0' }}>{products.length}</p>
                  <p className="text-xs text-gray-600 font-sans">Products</p>
                </div>
                <div className="p-3 rounded-sm text-center" style={{ background: 'rgba(255,255,255,0.03)' }}>
                  <p className="font-serif text-xl" style={{ fontFamily: 'Cormorant Garamond, serif', color: '#c0c0c0' }}>
                    {products.filter(p => p.featured).length}
                  </p>
                  <p className="text-xs text-gray-600 font-sans">Featured</p>
                </div>
              </div>
            </div>

            {/* Nav */}
            <nav className="flex-1 px-4 py-4 space-y-1">
              <div className="flex items-center gap-2 px-3 py-2 mb-3">
                <LayoutDashboard size={14} className="text-gray-600" />
                <span className="text-xs text-gray-600 tracking-widest uppercase font-sans">Navigation</span>
              </div>
              {tabs.map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-sm text-left transition-all duration-200 font-sans text-sm"
                  style={{
                    background: activeTab === key ? 'rgba(192,192,192,0.08)' : 'transparent',
                    color: activeTab === key ? '#c0c0c0' : '#555',
                    border: activeTab === key ? '1px solid rgba(192,192,192,0.1)' : '1px solid transparent',
                  }}
                >
                  <Icon size={16} />
                  {label}
                </button>
              ))}
            </nav>

            {/* Bottom */}
            <div className="px-4 py-4 space-y-2" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              <a
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-sm font-sans text-sm text-gray-500 hover:text-gray-300 transition-colors"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}
              >
                <ExternalLink size={14} />
                View Website
              </a>
              <button
                onClick={onLogout}
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-sm font-sans text-sm text-gray-600 hover:text-red-400 transition-colors"
              >
                <LogOut size={14} />
                Log Out
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div
        className="flex-1 transition-all duration-300"
        style={{ marginLeft: sidebarOpen ? '256px' : '0' }}
      >
        {/* Top bar */}
        <div
          className="sticky top-0 z-10 flex items-center justify-between px-6 py-4"
          style={{
            background: 'rgba(0,0,0,0.95)',
            backdropFilter: 'blur(10px)',
            borderBottom: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-500 hover:text-gray-300 transition-colors"
            >
              <LayoutDashboard size={18} />
            </button>
            <div>
              <h1 className="font-serif text-gray-100 text-xl" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                {tabs.find(t => t.key === activeTab)?.label}
              </h1>
              <p className="text-xs text-gray-600 font-sans">Royal Silver Admin</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Live preview toggle */}
            {(activeTab === 'content' || activeTab === 'marketing') && (
              <button
                onClick={togglePreview}
                className="flex items-center gap-2 px-4 py-2 rounded-sm text-xs font-sans tracking-wider transition-all duration-200"
                style={{
                  background: isPreviewMode ? 'rgba(192,192,192,0.12)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${isPreviewMode ? 'rgba(192,192,192,0.25)' : 'rgba(255,255,255,0.08)'}`,
                  color: isPreviewMode ? '#c0c0c0' : '#666',
                }}
              >
                {isPreviewMode ? <Eye size={14} /> : <EyeOff size={14} />}
                {isPreviewMode ? 'Preview ON' : 'Preview OFF'}
                {isPreviewMode && (
                  <span
                    className="live-preview-badge w-2 h-2 rounded-full"
                    style={{ background: '#c0c0c0' }}
                  />
                )}
              </button>
            )}
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-6 md:p-8 pb-24">
          {/* ---- PRODUCTS TAB ---- */}
          {activeTab === 'products' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <p className="text-gray-500 font-sans text-sm">
                  {products.length} items in catalog
                </p>
                <button
                  onClick={() => setEditingProduct({})}
                  className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold font-sans text-black tracking-wider transition-all duration-200"
                  style={{
                    background: 'linear-gradient(135deg, #d0d0d0 0%, #f5f5f5 100%)',
                    borderRadius: '2px',
                  }}
                >
                  <Plus size={16} />
                  Add Product
                </button>
              </div>

              {/* Product table */}
              <div
                className="rounded-sm overflow-hidden"
                style={{ border: '1px solid rgba(255,255,255,0.06)' }}
              >
                {/* Table header */}
                <div
                  className="grid grid-cols-12 px-5 py-3 text-xs tracking-widest uppercase font-sans"
                  style={{
                    color: '#555',
                    background: 'rgba(255,255,255,0.02)',
                    borderBottom: '1px solid rgba(255,255,255,0.05)',
                  }}
                >
                  <div className="col-span-1">IMG</div>
                  <div className="col-span-3">Name</div>
                  <div className="col-span-2">Category</div>
                  <div className="col-span-2">Price</div>
                  <div className="col-span-2">Purity</div>
                  <div className="col-span-1">⭐</div>
                  <div className="col-span-1">Actions</div>
                </div>

                {products.map((product, i) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="grid grid-cols-12 px-5 py-4 items-center group"
                    style={{
                      borderBottom: '1px solid rgba(255,255,255,0.04)',
                      transition: 'background 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.02)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLDivElement).style.background = 'transparent';
                    }}
                  >
                    {/* Image */}
                    <div className="col-span-1">
                      <div className="w-10 h-10 rounded-sm overflow-hidden">
                        <img
                          src={product.image_url}
                          alt={product.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=100&q=60';
                          }}
                        />
                      </div>
                    </div>

                    {/* Name */}
                    <div className="col-span-3">
                      <p className="font-serif text-gray-200 text-sm" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                        {product.name}
                      </p>
                    </div>

                    {/* Category */}
                    <div className="col-span-2">
                      <span
                        className="text-xs font-sans tracking-wider px-2 py-0.5 rounded-sm"
                        style={{
                          background: 'rgba(192,192,192,0.08)',
                          color: '#888',
                        }}
                      >
                        {product.category}
                      </span>
                    </div>

                    {/* Price */}
                    <div className="col-span-2">
                      <p className="font-serif text-gray-300 text-sm" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                        ₹{product.price.toLocaleString('en-IN')}
                      </p>
                    </div>

                    {/* Purity */}
                    <div className="col-span-2">
                      <span className="text-xs font-sans text-gray-500">{product.purity}% Pure</span>
                    </div>

                    {/* Featured */}
                    <div className="col-span-1">
                      <span className={`text-xs ${product.featured ? 'text-yellow-500' : 'text-gray-700'}`}>
                        {product.featured ? '★' : '☆'}
                      </span>
                    </div>

                    {/* Actions */}
                    <div className="col-span-1 flex items-center gap-2">
                      <button
                        onClick={() => setEditingProduct(product)}
                        className="p-1.5 rounded-sm text-gray-600 hover:text-gray-300 transition-colors"
                        title="Edit"
                      >
                        <Edit size={13} />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(product.id)}
                        className="p-1.5 rounded-sm text-gray-600 hover:text-red-400 transition-colors"
                        title="Delete"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </motion.div>
                ))}

                {products.length === 0 && (
                  <div className="text-center py-16 text-gray-600 font-sans text-sm">
                    No products yet. Click "Add Product" to get started.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ---- CONTENT TAB ---- */}
          {activeTab === 'content' && (
            <div className="max-w-2xl space-y-8">
              {isPreviewMode && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-sm text-xs font-sans"
                  style={{
                    background: 'rgba(192,192,192,0.06)',
                    border: '1px solid rgba(192,192,192,0.15)',
                    color: '#c0c0c0',
                  }}
                >
                  <span className="live-preview-badge w-2 h-2 rounded-full" style={{ background: '#c0c0c0' }} />
                  Live Preview is active — changes are visible on the website.
                  <a href="/" target="_blank" rel="noopener noreferrer" className="ml-auto flex items-center gap-1 hover:text-white transition-colors">
                    <ExternalLink size={12} />
                    Open Site
                  </a>
                </motion.div>
              )}

              {/* Hero Settings */}
              <div
                className="p-6 rounded-sm"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <h3 className="font-serif text-gray-200 text-xl mb-5" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                  Hero Section
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Main Title</label>
                    <input
                      className="luxury-input"
                      value={draftConfig.hero_title}
                      onChange={(e) => handleConfigChange('hero_title', e.target.value)}
                      placeholder="ROYAL SILVER"
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Tagline</label>
                    <input
                      className="luxury-input"
                      value={draftConfig.hero_tagline}
                      onChange={(e) => handleConfigChange('hero_tagline', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Subtitle / Founder Tag</label>
                    <input
                      className="luxury-input"
                      value={draftConfig.hero_subtitle}
                      onChange={(e) => handleConfigChange('hero_subtitle', e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Contact Settings */}
              <div
                className="p-6 rounded-sm"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <h3 className="font-serif text-gray-200 text-xl mb-5" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                  Contact & WhatsApp
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">
                      <Phone size={10} className="inline mr-1" />
                      Phone Number
                    </label>
                    <input
                      className="luxury-input"
                      value={draftConfig.contact_phone}
                      onChange={(e) => handleConfigChange('contact_phone', e.target.value)}
                      placeholder="7006630873"
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">
                      <MessageSquare size={10} className="inline mr-1" />
                      WhatsApp Number (used in all Buy CTAs)
                    </label>
                    <input
                      className="luxury-input"
                      value={draftConfig.whatsapp_number}
                      onChange={(e) => handleConfigChange('whatsapp_number', e.target.value)}
                      placeholder="7006630873"
                    />
                    <p className="text-xs text-gray-600 mt-1.5 font-sans">
                      This number is used across all WhatsApp CTA buttons site-wide.
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">Founder Name</label>
                    <input
                      className="luxury-input"
                      value={draftConfig.founder_name}
                      onChange={(e) => handleConfigChange('founder_name', e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <div className="flex items-center gap-4">
                <button
                  onClick={handleSaveConfig}
                  className="flex items-center gap-2 px-8 py-3 text-sm font-semibold font-sans text-black tracking-wider transition-all duration-200"
                  style={{
                    background: 'linear-gradient(135deg, #d0d0d0 0%, #f5f5f5 100%)',
                    borderRadius: '2px',
                  }}
                >
                  <Save size={14} />
                  Save All Changes
                </button>
                {saveSuccess && (
                  <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-xs font-sans text-green-400"
                  >
                    ✓ Saved successfully!
                  </motion.span>
                )}
              </div>
            </div>
          )}

          {/* ---- MARKETING TAB ---- */}
          {activeTab === 'marketing' && (
            <div className="max-w-2xl space-y-8">
              {isPreviewMode && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-sm text-xs font-sans"
                  style={{
                    background: 'rgba(192,192,192,0.06)',
                    border: '1px solid rgba(192,192,192,0.15)',
                    color: '#c0c0c0',
                  }}
                >
                  <span className="live-preview-badge w-2 h-2 rounded-full" style={{ background: '#c0c0c0' }} />
                  Live Preview active
                  <a href="/" target="_blank" rel="noopener noreferrer" className="ml-auto flex items-center gap-1 hover:text-white transition-colors">
                    <ExternalLink size={12} />Open Site
                  </a>
                </motion.div>
              )}

              {/* Announcement Bar */}
              <div
                className="p-6 rounded-sm"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-serif text-gray-200 text-xl" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                    Announcement Bar
                  </h3>
                  <label className="toggle-switch">
                    <input
                      type="checkbox"
                      checked={draftConfig.offer_bar_enabled}
                      onChange={(e) => handleConfigChange('offer_bar_enabled', e.target.checked)}
                    />
                    <span className="toggle-slider" />
                  </label>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-1.5">
                      Announcement Text
                    </label>
                    <textarea
                      className="luxury-input resize-none"
                      rows={3}
                      value={draftConfig.offer_bar_text}
                      onChange={(e) => handleConfigChange('offer_bar_text', e.target.value)}
                    />
                    <p className="text-xs text-gray-600 mt-1.5 font-sans">
                      This scrolling ticker will appear at the very top of the website.
                    </p>
                  </div>

                  {/* Preview of bar */}
                  {draftConfig.offer_bar_enabled && (
                    <div
                      className="p-3 rounded-sm overflow-hidden"
                      style={{
                        background: '#1a1a1a',
                        border: '1px solid rgba(192,192,192,0.1)',
                      }}
                    >
                      <p className="text-xs font-sans text-gray-400 truncate tracking-wider">
                        Preview: {draftConfig.offer_bar_text}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Status overview */}
              <div className="grid grid-cols-2 gap-4">
                <div
                  className="p-5 rounded-sm"
                  style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
                >
                  <p className="text-xs text-gray-600 font-sans mb-1">Announcement Bar</p>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${draftConfig.offer_bar_enabled ? 'bg-green-500' : 'bg-gray-700'}`} />
                    <span className="text-sm text-gray-300 font-sans">
                      {draftConfig.offer_bar_enabled ? 'Active' : 'Hidden'}
                    </span>
                  </div>
                </div>
                <div
                  className="p-5 rounded-sm"
                  style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
                >
                  <p className="text-xs text-gray-600 font-sans mb-1">WhatsApp CTA</p>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="text-sm text-gray-300 font-sans">Always Active</span>
                  </div>
                </div>
              </div>

              {/* Save */}
              <div className="flex items-center gap-4">
                <button
                  onClick={handleSaveConfig}
                  className="flex items-center gap-2 px-8 py-3 text-sm font-semibold font-sans text-black tracking-wider"
                  style={{
                    background: 'linear-gradient(135deg, #d0d0d0 0%, #f5f5f5 100%)',
                    borderRadius: '2px',
                  }}
                >
                  <Save size={14} />
                  Save Changes
                </button>
                {saveSuccess && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-xs font-sans text-green-400"
                  >
                    ✓ Saved!
                  </motion.span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Product Form Modal */}
      <AnimatePresence>
        {editingProduct !== null && (
          <ProductForm
            product={editingProduct}
            onSave={handleSaveProduct}
            onCancel={() => setEditingProduct(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
