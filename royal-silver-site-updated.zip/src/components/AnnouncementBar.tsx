import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useState } from 'react';
import { useDataStore } from '../store/dataStore';

export default function AnnouncementBar() {
  const [dismissed, setDismissed] = useState(false);
  const getActiveConfig = useDataStore((s) => s.getActiveConfig);
  const config = getActiveConfig();

  if (!config.offer_bar_enabled || dismissed) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: 'auto', opacity: 1 }}
        exit={{ height: 0, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="announcement-bar relative z-50 overflow-hidden"
      >
        <div className="flex items-center justify-center px-4 py-2.5 gap-3">
          <div className="overflow-hidden flex-1 min-w-0">
            <motion.p
              animate={{ x: ['0%', '-50%'] }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              className="whitespace-nowrap text-xs font-sans text-silver-200 tracking-widest inline-block"
              style={{ color: '#c0c0c0' }}
            >
              {config.offer_bar_text}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{config.offer_bar_text}
            </motion.p>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="flex-shrink-0 text-gray-400 hover:text-white transition-colors"
          >
            <X size={14} />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
