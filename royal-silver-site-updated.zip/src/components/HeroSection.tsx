import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';
import { useDataStore } from '../store/dataStore';

export default function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);
  const textY = useTransform(scrollYProgress, [0, 1], ['0%', '15%']);
  const opacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  const getActiveConfig = useDataStore((s) => s.getActiveConfig);
  const config = getActiveConfig();

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      id="hero"
    >
      {/* Background Image with Parallax */}
      <motion.div
        style={{ y: bgY }}
        className="absolute inset-0 z-0"
      >
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('/images/hero-bg.jpg')`,
            filter: 'brightness(0.35)',
          }}
        />
        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-black" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/40" />
      </motion.div>

      {/* Animated grid overlay */}
      <div className="absolute inset-0 z-0 opacity-5">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `linear-gradient(rgba(192,192,192,0.3) 1px, transparent 1px),
                             linear-gradient(90deg, rgba(192,192,192,0.3) 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      {/* Content */}
      <motion.div
        style={{ y: textY, opacity }}
        className="relative z-10 text-center px-6 max-w-5xl mx-auto"
      >
        {/* Founder tag */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex items-center justify-center gap-2 mb-8"
        >
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-silver-400" style={{ background: 'linear-gradient(90deg, transparent, #c0c0c0)' }} />
          <span className="text-xs tracking-[0.35em] uppercase text-gray-400 font-sans">
            <Sparkles size={10} className="inline mr-1" />
            {config.hero_subtitle}
          </span>
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-silver-400" style={{ background: 'linear-gradient(270deg, transparent, #c0c0c0)' }} />
        </motion.div>

        {/* Main Title */}
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="font-serif text-silver-gradient mb-4 leading-none tracking-tight"
          style={{
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: 'clamp(3.5rem, 12vw, 10rem)',
            fontWeight: 300,
            lineHeight: 0.9,
            letterSpacing: '-0.02em',
          }}
        >
          {config.hero_title}
        </motion.h1>

        {/* Decorative line */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 1, delay: 0.8, ease: 'easeOut' }}
          className="section-divider mx-auto my-8"
          style={{ width: '120px' }}
        />

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="text-gray-300 font-sans text-base md:text-xl tracking-widest mb-12 max-w-2xl mx-auto"
          style={{ letterSpacing: '0.15em' }}
        >
          {config.hero_tagline}
        </motion.p>

        {/* Purity badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 1.2 }}
          className="flex items-center justify-center gap-6 mb-12"
        >
          <div className="glass px-4 py-2 rounded-full border-flow flex items-center gap-2">
            <span className="text-xs font-semibold tracking-widest uppercase text-gray-300">92.5% Pure Silver</span>
          </div>
          <div className="glass px-4 py-2 rounded-full border-flow">
            <span className="text-xs font-semibold tracking-widest uppercase text-gray-300">Handcrafted</span>
          </div>
          <div className="glass px-4 py-2 rounded-full border-flow hidden sm:flex">
            <span className="text-xs font-semibold tracking-widest uppercase text-gray-300">Pan-India</span>
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.4 }}
          className="flex items-center justify-center gap-4 flex-wrap"
        >
          <a
            href="#collections"
            className="px-8 py-4 text-sm tracking-widest uppercase font-semibold text-black transition-all duration-300 hover:scale-105"
            style={{
              background: 'linear-gradient(135deg, #d0d0d0 0%, #ffffff 50%, #c0c0c0 100%)',
              borderRadius: '2px',
            }}
          >
            Explore Collections
          </a>
          <a
            href={`https://wa.me/91${config.whatsapp_number}?text=Hi! I'd like to know more about your silver jewelry.`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 text-sm tracking-widest uppercase font-semibold text-white border border-white/20 hover:border-white/50 transition-all duration-300 hover:bg-white/5"
            style={{ borderRadius: '2px' }}
          >
            Custom Order
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
      >
        <span className="text-xs tracking-widest uppercase text-gray-500 font-sans">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ArrowDown size={16} className="text-gray-500" />
        </motion.div>
      </motion.div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent z-5" />
    </section>
  );
}
