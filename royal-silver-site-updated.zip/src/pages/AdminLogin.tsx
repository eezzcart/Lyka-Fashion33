import { useState } from 'react';
import { motion } from 'framer-motion';
import { Crown, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useDataStore } from '../store/dataStore';

export default function AdminLogin({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const setAdminAuthenticated = useDataStore((s) => s.setAdminAuthenticated);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Demo authentication (replace with Supabase auth in production)
    await new Promise((r) => setTimeout(r, 800));

    if (email === 'owner@royalsilver.in' && password === 'RoyalSilverOwner2026!') {
      setAdminAuthenticated(true);
      onLogin();
    } else {
      setError('Invalid credentials. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-6 relative overflow-hidden">
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 60% at 50% 50%, rgba(192,192,192,0.04) 0%, transparent 70%)',
        }}
      />

      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(rgba(192,192,192,0.2) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(192,192,192,0.2) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        {/* Logo */}
        <div className="text-center mb-10">
          <div
            className="w-16 h-16 rounded-full border flex items-center justify-center mx-auto mb-4"
            style={{ borderColor: 'rgba(192,192,192,0.2)', background: 'rgba(192,192,192,0.04)' }}
          >
            <Crown size={24} style={{ color: '#c0c0c0' }} />
          </div>
          <h1
            className="font-serif text-3xl text-gray-100 mb-1"
            style={{ fontFamily: 'Cormorant Garamond, serif', fontWeight: 400 }}
          >
            Admin Panel
          </h1>
          <p className="text-gray-600 font-sans text-xs tracking-widest uppercase">Royal Silver CMS</p>
        </div>

        {/* Form */}
        <div
          className="p-8 rounded-sm"
          style={{
            background: 'rgba(255,255,255,0.02)',
            border: '1px solid rgba(255,255,255,0.07)',
          }}
        >
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@royalsilver.in"
                className="luxury-input"
                required
              />
            </div>

            <div>
              <label className="block text-xs tracking-widest uppercase text-gray-500 font-sans mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="luxury-input pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-3 rounded-sm text-xs font-sans"
                style={{
                  background: 'rgba(255,100,100,0.08)',
                  border: '1px solid rgba(255,100,100,0.15)',
                  color: '#f87171',
                }}
              >
                <AlertCircle size={14} />
                {error}
              </motion.div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 text-sm font-semibold tracking-widest uppercase font-sans transition-all duration-300 flex items-center justify-center gap-2 mt-2"
              style={{
                background: loading
                  ? 'rgba(192,192,192,0.1)'
                  : 'linear-gradient(135deg, #d0d0d0 0%, #f5f5f5 50%, #c0c0c0 100%)',
                color: loading ? '#555' : '#000',
                borderRadius: '2px',
                cursor: loading ? 'not-allowed' : 'pointer',
              }}
            >
              {loading ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
                    className="w-4 h-4 border-2 border-gray-600 border-t-gray-400 rounded-full"
                  />
                  Authenticating...
                </>
              ) : (
                <>
                  <Lock size={14} />
                  Sign In
                </>
              )}
            </button>
          </form>


        </div>

        <div className="text-center mt-6">
          <a href="/" className="text-xs text-gray-600 hover:text-gray-400 font-sans transition-colors tracking-widest">
            ← Back to Website
          </a>
        </div>
      </motion.div>
    </div>
  );
}
