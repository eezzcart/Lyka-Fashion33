import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Crown, ShieldCheck, Heart, Users } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      
      <main className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <p className="text-xs tracking-[0.4em] uppercase text-gray-500 font-sans mb-4">
              ✦ Our Story ✦
            </p>
            <h1 className="font-serif text-5xl md:text-7xl mb-6 text-silver-gradient">
              Royal Silver
            </h1>
            <div className="section-divider mb-8" />
            <p className="text-gray-400 text-lg max-w-2xl mx-auto leading-relaxed">
              Founded on the principles of purity and timeless elegance, Royal Silver brings masterfully crafted 92.5 sterling silver jewelry to those who appreciate the finer things in life.
            </p>
          </motion.div>

          {/* Content Sections */}
          <div className="space-y-24">
            {/* Mission */}
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="grid md:grid-cols-2 gap-12 items-center"
            >
              <div>
                <h2 className="font-serif text-3xl mb-6">Our Mission</h2>
                <p className="text-gray-400 leading-relaxed mb-4">
                  At Royal Silver, we believe that jewelry is more than just an accessory—it's a reflection of one's soul and a marker of life's most precious moments. Our mission is to provide authentic, high-quality silver pieces that stand the test of time.
                </p>
                <p className="text-gray-400 leading-relaxed">
                  Every piece in our collection is a testament to our commitment to excellence, from the initial sketch to the final polish.
                </p>
              </div>
              <div className="aspect-square rounded-sm overflow-hidden border border-white/10">
                <img 
                  src="https://images.unsplash.com/photo-1573408301185-9519f94816c8?w=800&q=80" 
                  alt="Craftsmanship" 
                  className="w-full h-full object-cover opacity-80"
                />
              </div>
            </motion.div>

            {/* Values */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { icon: Crown, title: "Uncompromising Quality", desc: "We use only 92.5% pure sterling silver, hallmarked for authenticity." },
                { icon: ShieldCheck, title: "Ethical Sourcing", desc: "Our materials are sourced from certified refineries with ethical practices." },
                { icon: Heart, title: "Artisan Crafted", desc: "Each piece is hand-finished by master craftsmen with decades of experience." },
                { icon: Users, title: "Customer First", desc: "We pride ourselves on providing a luxury experience for every customer." }
              ].map((value, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 glass rounded-sm border border-white/5"
                >
                  <value.icon className="text-silver mb-4" size={24} />
                  <h3 className="font-serif text-xl mb-2">{value.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{value.desc}</p>
                </motion.div>
              ))}
            </div>

            {/* Founder */}
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-center py-16 border-y border-white/5"
            >
              <h2 className="font-serif text-3xl mb-8">A Note from the Founder</h2>
              <blockquote className="text-2xl font-serif italic text-gray-300 max-w-3xl mx-auto mb-8">
                "Silver is not just a metal. It is a mirror to the soul — pure, timeless, and endlessly beautiful. We created Royal Silver to share this beauty with the world."
              </blockquote>
              <p className="text-silver tracking-widest uppercase text-sm">— Faisel Nazar</p>
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
