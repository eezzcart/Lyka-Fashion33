import { motion } from 'framer-motion';
import { useRef } from 'react';
import { Gem, Pencil, Hammer, Package } from 'lucide-react';

const craftSteps = [
  {
    number: '01',
    title: 'Sourcing',
    subtitle: 'Pure Origins',
    description:
      'We source only the finest 92.5 sterling silver ingots from certified refineries. Each batch is tested for purity before it enters our workshop.',
    icon: Gem,
    image: '/images/craft-sourcing.jpg',
  },
  {
    number: '02',
    title: 'Design',
    subtitle: 'Blueprint of Beauty',
    description:
      'Every piece begins as a hand-drawn sketch. Our designers blend timeless aesthetics with modern sensibility to create wearable art.',
    icon: Pencil,
    image: '/images/craft-design.jpg',
  },
  {
    number: '03',
    title: 'Hand-Finishing',
    subtitle: 'The Artisan\'s Touch',
    description:
      'Each ring is hand-polished, filed, and finished by master craftsmen with decades of experience. No two pieces are identical.',
    icon: Hammer,
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&q=80',
  },
  {
    number: '04',
    title: 'Luxury Packaging',
    subtitle: 'Unbox the Experience',
    description:
      'Your jewelry arrives in a handcrafted velvet box, sealed with our signature wax stamp — gift-ready from the moment it leaves our studio.',
    icon: Package,
    image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&q=80',
  },
];

export default function CraftSection() {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <section id="craft" className="py-24 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/30 to-black pointer-events-none" />

      <div className="relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 px-6"
        >
          <p className="text-xs tracking-[0.4em] uppercase text-gray-500 font-sans mb-4">
            ✦ Our Process ✦
          </p>
          <h2
            className="font-serif mb-4"
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(2.5rem, 6vw, 5rem)',
              fontWeight: 400,
              lineHeight: 1.1,
              background: 'linear-gradient(135deg, #c0c0c0 0%, #f5f5f5 40%, #a8a8a8 60%, #e8e8e8 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            The Craft
          </h2>
          <div className="section-divider mt-6" />
          <p className="mt-6 text-gray-400 font-sans text-sm max-w-lg mx-auto">
            From raw silver to wrist-ready masterpiece — four steps of obsessive detail.
          </p>
        </motion.div>

        {/* Horizontal Scroll Cards */}
        <div className="px-6 md:px-12">
          <div
            ref={scrollRef}
            className="horizontal-scroll-container"
          >
            {craftSteps.map((step, i) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, x: 40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: i * 0.1 }}
                  className="horizontal-scroll-item"
                  style={{ width: 'clamp(280px, 35vw, 420px)' }}
                >
                  <div
                    className="group h-full rounded-sm overflow-hidden relative"
                    style={{
                      background: 'rgba(255,255,255,0.02)',
                      border: '1px solid rgba(255,255,255,0.06)',
                      transition: 'all 0.4s ease',
                    }}
                  >
                    {/* Image */}
                    <div className="relative h-56 overflow-hidden">
                      <img
                        src={step.image}
                        alt={step.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&q=80';
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/10" />
                      {/* Step number overlay */}
                      <div className="absolute bottom-4 left-5">
                        <span
                          className="font-serif opacity-20 leading-none"
                          style={{
                            fontFamily: 'Cormorant Garamond, serif',
                            fontSize: '4rem',
                            fontWeight: 700,
                            color: '#c0c0c0',
                          }}
                        >
                          {step.number}
                        </span>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{
                            background: 'rgba(192,192,192,0.08)',
                            border: '1px solid rgba(192,192,192,0.15)',
                          }}
                        >
                          <Icon size={14} style={{ color: '#c0c0c0' }} />
                        </div>
                        <div>
                          <p className="text-xs tracking-widest uppercase text-gray-500 font-sans">{step.subtitle}</p>
                        </div>
                      </div>

                      <h3
                        className="font-serif mb-3 text-gray-100"
                        style={{
                          fontFamily: 'Cormorant Garamond, serif',
                          fontSize: '1.75rem',
                          fontWeight: 500,
                        }}
                      >
                        {step.title}
                      </h3>

                      <p className="text-gray-400 font-sans text-sm leading-relaxed">
                        {step.description}
                      </p>
                    </div>

                    {/* Bottom accent line */}
                    <div
                      className="absolute bottom-0 left-0 right-0 h-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      style={{ background: 'linear-gradient(90deg, transparent, #c0c0c0, transparent)' }}
                    />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Scroll hint */}
        <div className="text-center mt-6">
          <p className="text-xs tracking-widest text-gray-600 font-sans">← Scroll to explore →</p>
        </div>
      </div>
    </section>
  );
}
