import { Crown, Share2, Play, AtSign } from 'lucide-react';
const socialIcons = [Share2, Play, AtSign];
import { useDataStore } from '../store/dataStore';

export default function Footer() {
  const getActiveConfig = useDataStore((s) => s.getActiveConfig);
  const config = getActiveConfig();

  return (
    <footer className="relative py-16 px-6" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div
                className="w-8 h-8 border rounded-full flex items-center justify-center"
                style={{ borderColor: 'rgba(192,192,192,0.2)' }}
              >
                <Crown size={14} style={{ color: '#c0c0c0' }} />
              </div>
              <span
                className="text-sm font-semibold tracking-widest uppercase"
                style={{ fontFamily: 'Cormorant Garamond, serif', color: '#f0f0f0' }}
              >
                ROYAL SILVER
              </span>
            </div>
            <p className="text-gray-500 font-sans text-xs leading-relaxed mb-4 max-w-xs">
              Handcrafted 92.5 sterling silver jewelry by {config.founder_name}. 
              Every piece tells a story. What's yours?
            </p>
            <div className="flex items-center gap-3">
              {socialIcons.map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 hover:border-white/20"
                  style={{
                    background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    color: '#555',
                  }}
                >
                  <Icon size={13} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="text-xs tracking-[0.3em] uppercase font-sans mb-5"
              style={{ color: '#c0c0c0' }}
            >
              Quick Links
            </h4>
            <ul className="space-y-3">
              {[
                { label: 'Collections', href: '/#collections' },
                { label: 'The Craft', href: '/#craft' },
                { label: 'About Us', href: '/about' },
                { label: 'Contact', href: '/#contact' },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-gray-500 hover:text-gray-300 font-sans text-xs tracking-wide transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="text-xs tracking-[0.3em] uppercase font-sans mb-5"
              style={{ color: '#c0c0c0' }}
            >
              Contact
            </h4>
            <ul className="space-y-3">
              <li>
                <a
                  href={`https://wa.me/91${config.whatsapp_number}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-500 hover:text-gray-300 font-sans text-xs transition-colors"
                >
                  WhatsApp: +91 {config.whatsapp_number}
                </a>
              </li>
              <li>
                <a
                  href="mailto:royalsilver.in@gmail.com"
                  className="text-gray-500 hover:text-gray-300 font-sans text-xs transition-colors"
                >
                  royalsilver.in@gmail.com
                </a>
              </li>
              <li>
                <p className="text-gray-600 font-sans text-xs">Pan-India Shipping</p>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4"
          style={{ borderTop: '1px solid rgba(255,255,255,0.04)' }}
        >
          <p className="text-gray-700 font-sans text-xs tracking-wide">
            © {new Date().getFullYear()} Royal Silver. All rights reserved. | Hallmarked 92.5 Sterling Silver
          </p>
          <div className="flex items-center gap-6">
            <a href="/admin" className="text-gray-700 hover:text-gray-500 font-sans text-xs transition-colors">
              Admin
            </a>
            <p className="text-gray-700 font-sans text-xs">
              Crafted with ♡ by {config.founder_name}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
